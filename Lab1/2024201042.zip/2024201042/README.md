Question 1)
(i) To run question please first ensure proper executable permission is given. If not run the following command
-> chmod +x 2024201042_q1.sh
(ii) Then run the following command to execute the file
-> ./2024201042_q1.sh

Question 2)
(i) To run question please first ensure proper executable permission is given. If not run the following command
-> chmod +x 2024201042_q2.sh
(ii) Then run the following command to execute the file
-> ./2024201042_q2.sh

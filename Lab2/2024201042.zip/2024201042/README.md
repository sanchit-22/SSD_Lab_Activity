## Q1
* First give proper permission to executable file.
* Run the command ./2024201042_q1.sh <file_name>
* It will print the first 4 lines of the file.
* File must be unique

## Q2(a)
* First give proper permission to executable file.
* Run the command ./2024201042_q2a.sh
* It will ask for value of n
* Give value of n
* Now it will print n fibonacci numbers.

## Q2(b)
* First give proper permission to executable file.
* First set the export variable of A and B using * below command
* Export A=value
* Export B=value
* Now run the file ./2024201042_q2b.sh
* It will output the sum of the those export variable
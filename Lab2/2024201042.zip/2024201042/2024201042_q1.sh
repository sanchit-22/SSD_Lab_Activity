#!/bin/bash
file_path=$1
head -n 4  `locate $file_path`